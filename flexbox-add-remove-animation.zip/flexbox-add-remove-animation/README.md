# Flexbox add/remove animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/shatskiy/pen/ZOOrEV](https://codepen.io/shatskiy/pen/ZOOrEV).

